import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '../../../lib/supabase-admin'
import { cookies } from 'next/headers'
import { createServerClient } from '@supabase/ssr'

async function requireAdmin() {
  const cookieStore = cookies()
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { get: (n) => cookieStore.get(n)?.value } }
  )
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return null

  const admin = createAdminClient()
  const { data: profile } = await admin.from('profiles').select('is_admin').eq('id', session.user.id).single()
  return profile?.is_admin ? session : null
}

// POST /api/users – Benutzer erstellen
export async function POST(req: NextRequest) {
  const session = await requireAdmin()
  if (!session) return NextResponse.json({ error: 'Nicht authorisiert' }, { status: 403 })

  const { email, password, kurzname, natel, is_admin } = await req.json()
  if (!email || !password || !kurzname)
    return NextResponse.json({ error: 'email, password, kurzname sind pflicht' }, { status: 400 })

  const admin = createAdminClient()

  // Auth-User erstellen
  const { data: authData, error: authError } = await admin.auth.admin.createUser({
    email, password, email_confirm: true,
    user_metadata: { kurzname, natel },
  })
  if (authError) return NextResponse.json({ error: authError.message }, { status: 400 })

  // Profil aktualisieren (Trigger hat es erstellt, wir setzen is_admin)
  const { data: profile, error: profileError } = await admin
    .from('profiles')
    .update({ is_admin: !!is_admin, natel: natel || null })
    .eq('id', authData.user.id)
    .select()
    .single()

  if (profileError) return NextResponse.json({ error: profileError.message }, { status: 500 })
  return NextResponse.json({ user: profile }, { status: 201 })
}

// DELETE /api/users?id=xxx – Benutzer löschen
export async function DELETE(req: NextRequest) {
  const session = await requireAdmin()
  if (!session) return NextResponse.json({ error: 'Nicht authorisiert' }, { status: 403 })

  const id = req.nextUrl.searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id fehlt' }, { status: 400 })

  const admin = createAdminClient()
  const { error } = await admin.auth.admin.deleteUser(id)
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({ ok: true })
}
