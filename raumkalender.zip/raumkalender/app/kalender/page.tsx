import { redirect } from 'next/navigation'
import { cookies } from 'next/headers'
import { createServerClient } from '@supabase/ssr'
import { createAdminClient } from '../../lib/supabase-admin'
import Navbar from '../../components/Navbar'
import CalendarClient from './CalendarClient'

export default async function KalenderPage() {
  const cookieStore = cookies()
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { get: (n) => cookieStore.get(n)?.value } }
  )

  const { data: { session } } = await supabase.auth.getSession()
  if (!session) redirect('/login')

  const admin = createAdminClient()
  const { data: profile } = await admin
    .from('profiles')
    .select('kurzname, is_admin')
    .eq('id', session.user.id)
    .single()

  return (
    <>
      <Navbar kurzname={profile?.kurzname ?? session.user.email!} isAdmin={!!profile?.is_admin} />
      <main style={{ padding: '1.5rem', maxWidth: '1200px', margin: '0 auto' }}>
        <CalendarClient userId={session.user.id} kurzname={profile?.kurzname ?? ''} />
      </main>
    </>
  )
}
