'use client'
import { useState } from 'react'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'

interface ReservationModalProps {
  defaultStart?: Date
  onSave: (data: { title: string; start: Date; end: Date }) => Promise<void>
  onDelete?: () => Promise<void>
  onClose: () => void
  existing?: { title: string; start: Date; end: Date; kurzname: string }
  isOwner?: boolean
}

export default function ReservationModal({
  defaultStart, onSave, onDelete, onClose, existing, isOwner
}: ReservationModalProps) {
  const [title, setTitle] = useState(existing?.title ?? '')
  const [start, setStart] = useState<Date>(existing?.start ?? defaultStart ?? new Date())
  const [end,   setEnd]   = useState<Date>(existing?.end   ?? new Date((defaultStart ?? new Date()).getTime() + 60 * 60 * 1000))
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSave() {
    if (end <= start) { setError('Endzeit muss nach Startzeit liegen.'); return }
    setLoading(true); setError('')
    try { await onSave({ title, start, end }) }
    catch (e: any) { setError(e.message ?? 'Fehler beim Speichern') }
    setLoading(false)
  }

  async function handleDelete() {
    if (!onDelete) return
    setLoading(true)
    try { await onDelete() }
    catch (e: any) { setError(e.message ?? 'Fehler beim Löschen') }
    setLoading(false)
  }

  const readOnly = !!existing && !isOwner

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.35)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: '1rem'
    }} onClick={onClose}>
      <div className="card" style={{ width: '100%', maxWidth: '440px' }}
        onClick={e => e.stopPropagation()}>
        <h2 style={{ fontSize: '1.4rem', marginBottom: '1.25rem' }}>
          {existing ? 'Reservation' : 'Raum reservieren'}
        </h2>

        {existing && (
          <p style={{ color: 'var(--muted)', marginBottom: '1rem', fontSize: '0.9rem' }}>
            Gebucht von: <strong>{existing.kurzname}</strong>
          </p>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div>
            <label>Titel (optional)</label>
            <input value={title} disabled={readOnly}
              onChange={e => setTitle(e.target.value)} placeholder="z.B. Team-Meeting" />
          </div>
          <div>
            <label>Start</label>
            <DatePicker
              selected={start} disabled={readOnly}
              onChange={(d: Date | null) => d && setStart(d)}
              showTimeSelect timeFormat="HH:mm" timeIntervals={15}
              dateFormat="dd.MM.yyyy HH:mm"
              customInput={<input />}
            />
          </div>
          <div>
            <label>Ende</label>
            <DatePicker
              selected={end} disabled={readOnly}
              onChange={(d: Date | null) => d && setEnd(d)}
              showTimeSelect timeFormat="HH:mm" timeIntervals={15}
              dateFormat="dd.MM.yyyy HH:mm"
              customInput={<input />}
            />
          </div>
        </div>

        {error && <div className="error-msg" style={{ marginTop: '1rem' }}>{error}</div>}

        <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.5rem', justifyContent: 'flex-end' }}>
          <button className="btn btn-ghost" onClick={onClose}>Schliessen</button>
          {isOwner && onDelete && (
            <button className="btn btn-danger" onClick={handleDelete} disabled={loading}>Löschen</button>
          )}
          {!readOnly && (
            <button className="btn btn-primary" onClick={handleSave} disabled={loading}>
              {loading ? 'Speichern…' : 'Speichern'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
