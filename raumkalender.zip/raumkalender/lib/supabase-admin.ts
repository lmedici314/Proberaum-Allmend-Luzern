import { createClient } from '@supabase/supabase-js'

// Service-Role-Client: umgeht RLS – nur serverseitig verwenden!
export function createAdminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )
}
